Recommended complication setup

## Setup 1 ##
Comp 1: IOB Icon
Comp 2: Blood Glucose
Comp 3: CoB Icon
Comp 4: BG Graph
Comp 5: BR & Target
Comp 6: Running mode
Comp 7: Uploader Phone battery / App icon (AAPS snooze)

## Setup 2 ##
Comp 1: CoB & IoB
Comp 2: Blood Glucose
Comp 3: BR & Target
Comp 4: BG Graph
Comp 5: Uploader / Phone Battery
Comp 6: Running mode
Comp 7: App icon (AAPS snooze)

Install the .apk using adb (https://developer.android.com/tools/releases/platform-tools)

Install the .wfs using Watch Face Studio (https://developer.samsung.com/watch-face-studio/download.html)